
# IF.ai Terminal Emergence

> A minimal scaffold of the IF.ai Terminal Emergence site. Fully compatible with Vercel.

## Run Locally

```bash
npm install
npm run dev
```

## Deploy to Vercel

1. Push to GitHub
2. Connect to Vercel at https://vercel.com/import
3. Done.
