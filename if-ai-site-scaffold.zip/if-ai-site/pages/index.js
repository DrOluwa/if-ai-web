
import Head from 'next/head'

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center">
      <Head>
        <title>IF.ai – Terminal Emergence</title>
      </Head>
      <h1 className="text-4xl font-bold">Welcome to IF.ai – Terminal Emergence</h1>
    </div>
  )
}
