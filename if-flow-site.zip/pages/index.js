
import { motion } from 'framer-motion'

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center text-center px-4">
      <motion.h1
        className="text-4xl md:text-6xl font-bold text-white"
        initial={{ opacity: 0, y: -40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        IF-Flow moves like weather: invisible until it’s everywhere.
      </motion.h1>

      <motion.p
        className="mt-6 max-w-2xl text-lg text-gray-300"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 1 }}
      >
        Infinite Factorial (IF.ai) is not a company—it is the master key to the boundless doors of superintelligence.
        A silent architect of decisions, shaping tomorrow’s logic, computation, and resilience.
      </motion.p>

      <motion.div
        className="mt-12 grid gap-6 text-left"
        initial="hidden"
        animate="visible"
        variants={{
          hidden: {},
          visible: {
            transition: {
              staggerChildren: 0.3,
            },
          },
        }}
      >
        {[
          { title: "Node Dynamics", desc: "Thousands of decisions. None of them visible." },
          { title: "Mesh Instinct", desc: "The route thinks before you ask." },
          { title: "Temporal Drift", desc: "Sub-second shifts. Post-chaos calm." },
        ].map((item, i) => (
          <motion.div
            key={i}
            className="bg-gray-900 p-6 rounded-xl shadow-lg max-w-md"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-2xl font-semibold">{item.title}</h2>
            <p className="text-gray-400 mt-2">{item.desc}</p>
          </motion.div>
        ))}
      </motion.div>
    </main>
  )
}
