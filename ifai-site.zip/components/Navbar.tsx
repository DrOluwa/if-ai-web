import Link from "next/link";

const Navbar = () => {
  return (
    <nav className="flex justify-between items-center px-6 py-4 text-white bg-black fixed top-0 left-0 w-full z-50 backdrop-blur-md">
      <h1 className="text-2xl font-bold tracking-widest">∞ IF.ai</h1>
      <div className="space-x-6 text-lg">
        <Link href="/">Home</Link>
        <Link href="/agape">AGAPE Labs</Link>
        <Link href="/fractalwolf">FractalWolf</Link>
        <Link href="/if-fox">IF-Fox</Link>
        <Link href="/if-flow">IF-Flow</Link>
        <Link href="/manifesto">Manifesto</Link>
      </div>
    </nav>
  );
};

export default Navbar;
