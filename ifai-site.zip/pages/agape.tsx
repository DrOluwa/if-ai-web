import { motion } from "framer-motion";

const Agape = () => (
  <motion.div
    initial={{ opacity: 0, scale: 0.95 }}
    animate={{ opacity: 1, scale: 1 }}
    exit={{ opacity: 0, scale: 1.05 }}
    transition={{ duration: 0.6 }}
    className="min-h-screen p-4 pt-32 md:p-20 text-white bg-gradient-to-br from-black via-slate-900 to-blue-900"
  >
    <h1 className="text-4xl md:text-6xl font-extrabold mb-8 tracking-tight">AGAPE Labs</h1>
    <p className="text-xl md:text-2xl leading-relaxed">Elegance in absence. Invisibility as medium. More soon…</p>
  </motion.div>
);

export default Agape;
