import { motion } from "framer-motion";

const FractalWolf = () => (
  <motion.div
    initial={{ opacity: 0, scale: 0.9 }}
    animate={{ opacity: 1, scale: 1 }}
    exit={{ opacity: 0, scale: 1.1 }}
    transition={{ duration: 0.6 }}
    className="min-h-screen p-4 pt-32 md:p-20 text-white bg-gradient-to-br from-black via-red-900 to-fuchsia-900"
  >
    <h1 className="text-4xl md:text-6xl font-extrabold mb-8 tracking-tight">FractalWolf: Hunter Logic Made Flesh</h1>
    <p className="text-xl md:text-2xl leading-relaxed">Predator in the mesh. Tactical intelligence embedded in motion. More soon…</p>
  </motion.div>
);

export default FractalWolf;
