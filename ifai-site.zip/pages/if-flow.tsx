import { motion } from "framer-motion";

const IFFlow = () => (
  <motion.div
    initial={{ opacity: 0, y: 30 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -30 }}
    transition={{ duration: 0.6 }}
    className="min-h-screen p-4 pt-32 md:p-20 text-white bg-gradient-to-br from-gray-900 via-cyan-800 to-emerald-700"
  >
    <h1 className="text-4xl md:text-6xl font-extrabold mb-8 tracking-tight">IF-Flow</h1>
    <p className="text-xl md:text-2xl leading-relaxed">Systems that adapt like weather. Flow states made code. More soon…</p>
  </motion.div>
);

export default IFFlow;
