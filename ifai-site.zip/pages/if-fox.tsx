import { motion } from "framer-motion";

const IFFox = () => (
  <motion.div
    initial={{ opacity: 0, y: 40 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -40 }}
    transition={{ duration: 0.6 }}
    className="min-h-screen p-4 pt-32 md:p-20 text-white bg-gradient-to-br from-gray-900 via-rose-800 to-orange-700"
  >
    <h1 className="text-4xl md:text-6xl font-extrabold mb-8 tracking-tight">IF-Fox: The Interface Instinct</h1>
    <p className="text-xl md:text-2xl leading-relaxed">Elegant foresight. UX that adapts with you. More soon…</p>
  </motion.div>
);

export default IFFox;
