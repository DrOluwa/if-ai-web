import { motion } from "framer-motion";

const Home = () => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.6 }}
    className="min-h-screen p-4 pt-32 md:p-20 text-white bg-gradient-to-br from-black via-gray-900 to-indigo-950"
  >
    <h1 className="text-4xl md:text-6xl font-extrabold mb-8 tracking-tight">Welcome to IF.ai</h1>
    <p className="text-xl md:text-2xl leading-relaxed">Infinite systems. Elegant intelligence. Navigate beyond.</p>
  </motion.div>
);

export default Home;
