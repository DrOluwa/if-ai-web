import { motion } from "framer-motion";

const Manifesto = () => (
  <motion.div
    initial={{ opacity: 0, x: 30 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: -30 }}
    transition={{ duration: 0.6 }}
    className="min-h-screen p-4 pt-32 md:p-20 text-white bg-gradient-to-br from-black via-zinc-800 to-violet-800"
  >
    <h1 className="text-4xl md:text-6xl font-extrabold mb-8 tracking-tight">The Infinite Factorial Manifesto</h1>
    <p className="text-xl md:text-2xl leading-relaxed">Unlocking humanity’s abundance. Intelligence through chaos. More soon…</p>
  </motion.div>
);

export default Manifesto;
